use std::{env, path::PathBuf, process::ExitCode};

use clap::{Args, Parser, Subcommand};
use serde::Serialize;
use serde_json::{Value, json};
use svc_core::engine::{
    add_def_at, classify_def, delete, diff as diff_snapshots, edit_def, extract_hoist, inline,
    move_def, relocate, rename, render_entity, resolve_add_def_file, show,
};
use svc_core::{EntityId, Intent, NoteKind, Op, OpIx, RelPath, Snapshot, SnapshotId};
use svc_repo::{
    Repo, Take, blame, branch, changeset_begin, changeset_end, changeset_reopen, changeset_show,
    changeset_status, changesets, checkout, claim, conflicts as list_conflicts, describe, edit, evolog,
    heads, inbox, log, mail, mail_read, merge as merge_repo, new, notes_about_entity, op_log, op_restore,
    release, replay, resolve as resolve_conflict, resolve_changeset, resolve_entity, resolve_entity_in,
    review, status, undo, untracked_mentions, workspace,
};

mod agent;

#[derive(Parser)]
#[command(name = "svc", about = "Compiler-grade version control")]
struct Cli {
    #[arg(long, global = true)] json: bool,
    #[command(subcommand)] command: Command,
}

#[derive(Subcommand)]
enum Command {
    Init, Status, Describe { message: String }, New, Branch { name: String }, Edit { change: String }, Heads, Log,
    Evolog { change: String }, Show { entity: String }, ListDefs, ShowDef(ShowDefArgs),
    Search { query: String }, Diff { a: String, b: String }, Blame(EntityArg),
    Merge { change: String }, Conflicts,
    Resolve { conflict: usize, #[arg(long, help = "a = current change, b = merged-in, or base")] take: String },
    Undo,
    #[command(subcommand)] Op(OpCommand),
    #[command(subcommand)] Changeset(ChangeSetCommand),
    /// The local forge (crates/svc-forge): `export` writes its catalog from this store.
    #[command(subcommand)] Forge(ForgeCommand),
    #[command(subcommand)] History(HistoryCommand),
    /// Send a changeset (its ops and their verdicts) to the checkout at DIR; a second push sends only what is new.
    Push { changeset: String, dir: PathBuf },
    /// Take a changeset from the checkout at DIR into this store.
    Pull { changeset: String, dir: PathBuf },
    #[command(subcommand)] Workspace(WorkspaceCommand),
    Checkout { snapshot: String }, Render, Replay, Rename(RenameArgs), Move(MoveArgs),
    Relocate(RelocateArgs), Extract(ExtractArgs), Inline(EntityArg), AddDef(AddDefArgs),
    Delete(DeleteArgs), EditDef(EditDefArgs), Classify(ClassifyArgs), Agent { task: String },
    /// Review a changeset: the mailbox half of a PR, stored as `Op::Note`.
    Review(ReviewArgs),
    /// Mail another checkout, or `@all`. `--about` hangs it on an entity or changeset.
    Mail(MailArgs),
    /// Unread notes addressed to this checkout or `@all`.
    Inbox,
    /// Record that this checkout is editing an entity or every entity in a file.
    Claim { targets: Vec<String> },
    /// Drop a claim (`svc release` drops this checkout's claims).
    Release { targets: Vec<String> },
    /// Open the review UI; with `--agent <task>`, run that task under dsh inside it (demo line 12).
    Tui { #[arg(long)] agent: Option<String>, #[arg(long)] wire_log: bool },
}

#[derive(Subcommand)] enum OpCommand { Log, Restore { index: u64 } }
#[derive(Subcommand)] enum ForgeCommand { Export { #[arg(long)] out: Option<std::path::PathBuf> } }
#[derive(Subcommand)]
enum HistoryCommand {
    /// The op log from --since (default 1: everything after init) as a bundle, to stdout or --out.
    Export { #[arg(long, default_value_t = 1)] since: u64, #[arg(long)] out: Option<PathBuf> },
    /// Replay a bundle into this store; the tree must be the bundle's base.
    Import { file: PathBuf },
}
#[derive(Subcommand)]
enum WorkspaceCommand {
    Add { name: String, path: PathBuf, #[arg(long)] at: Option<String> },
    List,
    Forget { name: String },
    UpdateStale,
}
#[derive(Subcommand)]
enum ChangeSetCommand {
    Begin { name: String, #[arg(long, default_value = "refactor")] intent: String, #[arg(long)] force: bool },
    End,
    /// Make an existing changeset (id, prefix or name) the open one again.
    Reopen { changeset: String },
    Status,
    List,
    Show { changeset: String },
}
#[derive(Args)] struct EntityArg { #[arg(long)] entity: String }
#[derive(Args)] struct ShowDefArgs { #[arg(long)] entity: String, #[arg(long)] at: Option<String> }
#[derive(Args)] struct RenameArgs { #[arg(long)] entity: String, #[arg(long)] new_name: String }
#[derive(Args)] struct MoveArgs { #[arg(long)] entity: String, #[arg(long)] new_parent: String, #[arg(long)] ordinal: Option<u32> }
#[derive(Args)] struct RelocateArgs { #[arg(long)] entity: String, #[arg(long)] file: String, #[arg(long)] ordinal: u32 }
#[derive(Args)] struct ExtractArgs { #[arg(long)] entity: String, #[arg(long)] new_parent: Option<String> }
#[derive(Args)] struct AddDefArgs { #[arg(long)] id: Option<String>, #[arg(long)] parent: Option<String>, #[arg(long)] file: Option<String>, #[arg(long)] ordinal: u32, #[arg(long)] definition: String, #[arg(long)] intent: String }
#[derive(Args)] struct DeleteArgs { #[arg(long)] entity: String, #[arg(long)] intent: String }
#[derive(Args)] struct EditDefArgs { #[arg(long)] entity: String, #[arg(long)] definition: String, #[arg(long)] intent: String }
#[derive(Args)] struct ClassifyArgs { #[arg(long)] entity: String, #[arg(long)] definition: String }
#[derive(Args)]
struct ReviewArgs {
    changeset: String,
    #[arg(long, group = "verdict")]
    approve: bool,
    #[arg(long, group = "verdict")]
    request_changes: bool,
    #[arg(long, group = "verdict")]
    note: Option<String>,
}
#[derive(Args)]
struct MailArgs {
    /// Checkout name, or `@all`. Omitted with `--read`.
    to: Option<String>,
    /// Message body. Omitted with `--read`.
    message: Option<String>,
    #[arg(long)]
    about: Option<String>,
    /// Mark notes through this op index as read.
    #[arg(long)]
    read: Option<u64>,
}

fn main() -> ExitCode {
    // `svc list-defs --json | head` must not panic with "failed printing to stdout: Broken
    // pipe": restore SIGPIPE's default so a closed pipe ends the process quietly, as it
    // does for every other CLI tool.
    #[cfg(unix)]
    {
        unsafe extern "C" {
            fn signal(signum: i32, handler: usize) -> usize;
        }
        unsafe { signal(13 /* SIGPIPE */, 0 /* SIG_DFL */) };
    }
    let cli = Cli::parse();
    if let Command::Tui { agent: task, wire_log } = &cli.command {
        let cwd = match env::current_dir().and_then(|path| path.canonicalize()) {
            Ok(cwd) => cwd,
            Err(error) => {
                eprintln!("svc: could not resolve repository root: {error}");
                return ExitCode::FAILURE;
            }
        };
        let root = Repo::find_root(&cwd).unwrap_or(cwd);
        let svc_bin = match env::current_exe() {
            Ok(path) => path,
            Err(error) => {
                eprintln!("svc: could not locate its executable: {error}");
                return ExitCode::FAILURE;
            }
        };
        // Same launch as `svc agent`: pinned dsh, runtime overlay, SVC_BIN; the TUI opens
        // and closes the run's changeset itself and answers asks from its queue.
        // SVC_AGENT_COMMAND="node demo/replay-agent.mjs <recording>" hosts a scripted ACP
        // agent instead, for rehearsing line 12 without a model key.
        let agent = match task {
            None => None,
            Some(task) => match env::var("SVC_AGENT_COMMAND") {
                Ok(command) => {
                    let mut words = command.split_whitespace().map(str::to_string);
                    let Some(program) = words.next() else {
                        eprintln!("svc: SVC_AGENT_COMMAND is empty");
                        return ExitCode::FAILURE;
                    };
                    let mut config = svc_agent::AgentConfig::command(program, words.collect(), &root);
                    config.env.insert("SVC_BIN".into(), svc_bin.display().to_string());
                    Some((config, task.clone()))
                }
                Err(_) => {
                    if !agent::has_model_credentials() {
                        eprintln!("svc: no model credential found; set OPENROUTER_API_KEY, DEEPSEEK_API_KEY, ANTHROPIC_API_KEY, OPENAI_API_KEY, or XAI_API_KEY");
                        return ExitCode::FAILURE;
                    }
                    match agent::runtime_overlay(&root) {
                        Ok(overlay) => Some((svc_agent::AgentConfig::dsh(&root, &overlay, &svc_bin), task.clone())),
                        Err(error) => {
                            eprintln!("svc: {error}");
                            return ExitCode::FAILURE;
                        }
                    }
                }
            },
        };
        return match svc_tui::run(svc_tui::TuiOptions {
            svc_bin,
            root,
            agent,
            wire_log: *wire_log,
        }) {
            Ok(()) => ExitCode::SUCCESS,
            Err(error) => {
                eprintln!("svc: {error}");
                ExitCode::FAILURE
            }
        };
    }
    if let Command::Agent { task } = &cli.command {
        let runtime = match tokio::runtime::Runtime::new() {
            Ok(runtime) => runtime,
            Err(error) => {
                eprintln!("svc: could not start async runtime: {error}");
                return ExitCode::FAILURE;
            }
        };
        return match runtime.block_on(agent::run(task)) {
            Ok(()) => ExitCode::SUCCESS,
            Err(error) => {
                eprintln!("svc: {error}");
                ExitCode::FAILURE
            }
        };
    }
    if !cli.json {
        if let Some(result) = run_text(&cli) {
            return match result {
                Ok(text) => { println!("{text}"); ExitCode::SUCCESS }
                Err(error) => { eprintln!("svc: {error}"); ExitCode::FAILURE }
            };
        }
    }
    match run(&cli) {
        Ok(value) => { println!("{}", if cli.json { value.to_string() } else { serde_json::to_string_pretty(&value).unwrap() }); ExitCode::SUCCESS }
        Err(error) => { if cli.json { eprintln!("{}", json!({"error": error})) } else { eprintln!("svc: {error}") }; ExitCode::FAILURE }
    }
}

/// The sentence form of the verbs whose output people read at the expo (design §8: `--json`
/// is the machine form). `None` for every other verb, which then takes the JSON path.
fn run_text(cli: &Cli) -> Option<Result<String, String>> {
    use svc_repo::text;
    // `init` has to run before discover: there is no store yet.
    if matches!(cli.command, Command::Init) {
        return Some(init_text());
    }
    let cwd = env::current_dir().ok()?;
    let repo = Repo::discover(&cwd, Repo::default_langs()).ok()?;
    let snap = repo.current().ok()?;
    let out = match &cli.command {
        Command::Status => status(&repo).and_then(|s| repo.current().map(|snap| text::status(&snap, &s))),
        Command::Log => log(&repo, None).map(|l| text::log(&snap, &l)),
        Command::Op(OpCommand::Log) => op_log(&repo).map(|l| text::log(&snap, &l)),
        Command::Forge(ForgeCommand::Export { out }) => svc_repo::forge::export(&repo, out.as_deref())
            .map(|p| format!("wrote {} — serve it with: cargo run -p svc-forge -- --catalog {}", p.display(), p.display())),
        Command::History(HistoryCommand::Export { since, out }) => {
            return Some((|| {
                let b = svc_repo::bundle::export(&repo, OpIx(*since)).map_err(|e| e.to_string())?;
                match out {
                    Some(p) => {
                        let text = serde_json::to_string_pretty(&b).map_err(|e| e.to_string())?;
                        std::fs::write(p, text).map_err(|e| e.to_string())?;
                        Ok(format!("wrote {}: {} ops", p.display(), b.entries.len()))
                    }
                    None => serde_json::to_string_pretty(&b).map_err(|e| e.to_string()),
                }
            })());
        }
        Command::Push { changeset, dir } | Command::Pull { changeset, dir } => {
            let pushing = matches!(cli.command, Command::Push { .. });
            return Some(run_with(cli, &repo).map(|v| {
                let sent = v["sent"].as_u64().unwrap_or(0);
                let (verb, prep) = if pushing { ("pushed", "to") } else { ("pulled", "from") };
                match sent {
                    0 if pushing => format!("nothing to push: {} already has every op of changeset {changeset}", dir.display()),
                    0 => format!("nothing to pull: every op of changeset {changeset} at {} is already here", dir.display()),
                    n => format!("{verb} {n} op{} of changeset {changeset} {prep} {}", if n == 1 { "" } else { "s" }, dir.display()),
                }
            }));
        }
        Command::Changeset(ChangeSetCommand::Reopen { .. }) => {
            return Some(run_with(cli, &repo).map(|v| format!("changeset {} open again", v["name"].as_str().unwrap_or("?"))));
        }
        Command::History(HistoryCommand::Import { file }) => {
            return Some((|| {
                let text = std::fs::read_to_string(file).map_err(|e| e.to_string())?;
                let b: svc_repo::bundle::Bundle = serde_json::from_str(&text).map_err(|e| e.to_string())?;
                let r = svc_repo::bundle::import(&repo, &b).map_err(|e| e.to_string())?;
                Ok(match r.diverged_at {
                    Some(at) => format!("replayed {} ops: diverged at #{}", r.applied, at.0),
                    None => format!("replayed {} ops: clean", r.applied),
                })
            })());
        }
        Command::Heads => heads(&repo).map(|h| text::heads(&h)),
        Command::Evolog { change } => repo
            .resolve_change(change)
            .and_then(|id| evolog(&repo, id))
            .map(|e| text::evolog(&e)),
        Command::Blame(arg) => resolve_entity(&repo, &arg.entity)
            .and_then(|id| blame(&repo, id))
            .map(|b| text::blame(&snap, &b)),
        Command::Conflicts => list_conflicts(&repo).map(|c| text::conflicts_named(&snap, repo.store(), repo.root_dir(), &c)),
        Command::Replay => replay(&repo).and_then(|r| {
            if r.ok() {
                Ok(format!("replayed {} operations: clean", r.ops))
            } else {
                Err(svc_core::Error::Other(format!(
                    "replay diverged at {:?}",
                    r.diverged_at
                )))
            }
        }),
        Command::Workspace(WorkspaceCommand::List) => {
            return Some(
                workspace::list(&repo)
                    .map(|rows| {
                        rows.iter()
                            .map(|row| {
                                let mark = if row.current { "@" } else { " " };
                                let change = row
                                    .change
                                    .as_ref()
                                    .map(|id| format!("  change⟨{}⟩", id.short()))
                                    .unwrap_or_default();
                                format!("{mark} {:<8} {}{change}", row.name, row.path.display())
                            })
                            .collect::<Vec<_>>()
                            .join("\n")
                    })
                    .map_err(|e| e.to_string()),
            );
        }
        Command::Merge { change } => merge_repo(&repo, change)
            .and_then(|m| repo.current().map(|s| text::merge(&s, repo.store(), repo.root_dir(), &m))),
        Command::Show { entity } => {
            // demo line 3: the canonical stream — `$n` local slots, `#name⟨hash⟩` refs.
            return Some(show_canonical(&repo, entity).map(|v| {
                format!("{entity}⟨{}⟩\n{}", v["short"].as_str().unwrap_or(""), v["canonical"].as_str().unwrap_or(""))
            }));
        }
        Command::New
        | Command::Branch { .. }
        | Command::Describe { .. }
        | Command::Undo
        | Command::Move(_)
        | Command::Relocate(_)
        | Command::Extract(_)
        | Command::Inline(_)
        | Command::AddDef(_)
        | Command::Delete(_)
        | Command::EditDef(_) => {
            return Some(run_with(cli, &repo).and_then(|v| text_of_this_op(&repo, &v)));
        }
        Command::Rename(args) => {
            return Some(rename_cmd(&repo, args).map(|v| {
                let from = v["renamed"]["from"].as_str().unwrap_or("?").to_string();
                let calls = v["untracked_mentions"]["method_calls"].as_u64().unwrap_or(0);
                let other = v["untracked_mentions"]["other"].as_u64().unwrap_or(0);
                let plural = |n: u64, s: &str| if n == 1 { s.to_string() } else { format!("{s}s") };
                let mut line = format!("renamed {from} → {}", args.new_name);
                if calls > 0 {
                    line.push_str(&format!(
                        "\n{calls} method {} `.{from}(…)` left unchanged: receiver types are not resolved",
                        plural(calls, "call")
                    ));
                }
                if other > 0 {
                    line.push_str(&format!(
                        "\n{other} other {} of `{from}` left unchanged (strings, comments, unrelated bindings)",
                        plural(other, "mention")
                    ));
                }
                line
            }));
        }
        Command::ListDefs => {
            let mut rows: Vec<_> = snap
                .entities
                .iter()
                .map(|(id, e)| (e.file.clone(), e.ordinal, e.kind, e.name.clone(), *id))
                .collect();
            rows.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.cmp(&b.1)).then(a.3.cmp(&b.3)));
            let body = rows
                .into_iter()
                .map(|(file, _, kind, name, id)| format!("{kind:?} {name}  {file}  ⟨{}⟩", id.short()))
                .collect::<Vec<_>>()
                .join("\n");
            return Some(Ok(if body.is_empty() { "no definitions".into() } else { body }));
        }
        Command::ShowDef(arg) => return Some(show_def_text(&repo, &arg.entity, arg.at.as_deref())),
        Command::Search { query } => {
            return Some(search(&repo, query).map(|v| {
                let matches = v["matches"].as_array().cloned().unwrap_or_default();
                if matches.is_empty() {
                    format!("no matches for {query:?}")
                } else {
                    matches
                        .iter()
                        .map(|m| {
                            format!(
                                "{} {}  {}",
                                m["kind"].as_str().unwrap_or("?"),
                                m["name"].as_str().unwrap_or("?"),
                                m["file"].as_str().unwrap_or("")
                            )
                        })
                        .collect::<Vec<_>>()
                        .join("\n")
                }
            }));
        }
        Command::Classify(args) => {
            return Some(classify_cmd(&repo, args).map(|v| {
                format!(
                    "{} would be {} (not committed)",
                    args.entity,
                    v["observed"].as_str().unwrap_or("?")
                )
            }));
        }
        Command::Workspace(WorkspaceCommand::Add { name, path, .. }) => {
            return Some(run_with(cli, &repo).map(|v| {
                let shown = v["path"].as_str().map(str::to_string).unwrap_or_else(|| path.display().to_string());
                format!("added workspace {name} at {shown}")
            }));
        }
        Command::Workspace(WorkspaceCommand::Forget { name }) => {
            return Some(run_with(cli, &repo).map(|_| format!("forgot workspace {name}")));
        }
        Command::Workspace(WorkspaceCommand::UpdateStale) => {
            return Some(run_with(cli, &repo).map(|v| {
                format!("workspace {} is current", v["name"].as_str().unwrap_or("default"))
            }));
        }
        Command::Edit { change } => {
            return Some(edit(&repo, change).map(|_| format!("now editing {change}")).map_err(|e| e.to_string()));
        }
        Command::Checkout { snapshot } => {
            return Some((|| {
                let id = snapshot.parse::<SnapshotId>().map_err(|e| e.to_string())?;
                checkout(&repo, id).map_err(|e| e.to_string())?;
                Ok(format!("checked out {snapshot}"))
            })());
        }
        Command::Render => {
            return Some(run_with(cli, &repo).map(|_| "rendered working copy".into()));
        }
        Command::Resolve { conflict, take } => {
            return Some(run_with(cli, &repo).map(|_| format!("took {take} on conflict {conflict}")));
        }
        Command::Op(OpCommand::Restore { index }) => {
            return Some(run_with(cli, &repo).and_then(|v| {
                text_of_this_op(&repo, &v).map(|s| {
                    if s.is_empty() {
                        format!("restored op {index}")
                    } else {
                        s
                    }
                })
            }));
        }
        Command::Diff { a, b } => {
            return Some((|| {
                let left = resolve_snapshot(&repo, a)?;
                let right = resolve_snapshot(&repo, b)?;
                let deltas = diff_snapshots(repo.store(), &left, &right).map_err(|e| e.to_string())?;
                if deltas.is_empty() {
                    Ok("no differences".into())
                } else {
                    Ok(deltas.iter().map(|d| text::delta(&right, d)).collect::<Vec<_>>().join("\n"))
                }
            })());
        }
        Command::Changeset(ChangeSetCommand::Begin { name, .. }) => {
            return Some(run_with(cli, &repo).map(|_| format!("changeset {name} open")));
        }
        Command::Changeset(ChangeSetCommand::End) => {
            return Some(run_with(cli, &repo).map(|v| {
                if v.is_null() {
                    "no open changeset".into()
                } else {
                    format!("closed changeset {}", v.as_str().unwrap_or("?"))
                }
            }));
        }
        Command::Changeset(ChangeSetCommand::Status) => {
            return Some(run_with(cli, &repo).map(|v| {
                if v.is_null() {
                    "no open changeset".into()
                } else {
                    format!(
                        "open changeset {} ({} ops)",
                        v["name"].as_str().unwrap_or("?"),
                        v["ops"].as_array().map(|a| a.len()).unwrap_or(0)
                    )
                }
            }));
        }
        Command::Changeset(ChangeSetCommand::List) => {
            return Some(
                changesets(&repo)
                    .map(|rows| {
                        if rows.is_empty() {
                            "no changesets".into()
                        } else {
                            rows.iter()
                                .map(|c| {
                                    let mark = if c.open { "*" } else { " " };
                                    format!("{mark} {} ({:?}, {} ops)", c.name, c.intent, c.ops.len())
                                })
                                .collect::<Vec<_>>()
                                .join("\n")
                        }
                    })
                    .map_err(|e| e.to_string()),
            );
        }
        Command::Changeset(ChangeSetCommand::Show { changeset }) => {
            return Some(changeset_show(&repo, changeset).map(|c| {
                let mut lines = vec![format!(
                    "changeset {} ({:?}, {} ops, {} reviews)",
                    c.name,
                    c.intent,
                    c.ops.len(),
                    c.reviews.len()
                )];
                for r in &c.reviews {
                    lines.push(format!("  {}", text::op(&snap, r)));
                }
                lines.join("\n")
            }).map_err(|e| e.to_string()));
        }
        Command::Review(_) | Command::Claim { .. } | Command::Release { .. } => {
            return Some(run_with(cli, &repo).and_then(|v| {
                if let Some(arr) = v.as_array() {
                    let snap = repo.current().map_err(|e| e.to_string())?;
                    let log = op_log(&repo).map_err(|e| e.to_string())?;
                    Ok(arr
                        .iter()
                        .filter_map(|item| {
                            let ix = item["ix"].as_u64().or_else(|| item["op"].as_u64())?;
                            log.iter().find(|e| e.ix.0 == ix).map(|e| text::op(&snap, e))
                        })
                        .collect::<Vec<_>>()
                        .join("\n"))
                } else {
                    text_of_this_op(&repo, &v)
                }
            }));
        }
        Command::Mail(args) if args.read.is_some() => {
            return Some(run_with(cli, &repo).map(|v| inbox_text(&v)));
        }
        Command::Mail(_) => {
            return Some(run_with(cli, &repo).and_then(|v| text_of_this_op(&repo, &v)));
        }
        Command::Inbox => {
            return Some(inbox(&repo).map(|box_| {
                if box_.unread.is_empty() {
                    "inbox empty".into()
                } else {
                    box_.unread
                        .iter()
                        .map(|e| text::op(&snap, e))
                        .collect::<Vec<_>>()
                        .join("\n")
                }
            }).map_err(|e| e.to_string()));
        }
        _ => return None,
    };
    Some(out.map_err(|e| e.to_string()))
}

fn run(cli: &Cli) -> Result<Value, String> {
    if matches!(cli.command, Command::Init) {
        let cwd = env::current_dir().map_err(|e| e.to_string())?;
        let repo = Repo::init(&cwd, Repo::default_langs()).map_err(|e| e.to_string())?;
        return Ok(json!({"root": repo.root_dir(), "change": repo.current_change().map_err(|e| e.to_string())?}));
    }
    let cwd = env::current_dir().map_err(|e| e.to_string())?;
    let repo = Repo::discover(&cwd, Repo::default_langs()).map_err(|e| e.to_string())?;
    run_with(cli, &repo)
}

/// The verb dispatch over an already-open repository (redb admits one opener per process).
fn run_with(cli: &Cli, repo: &Repo) -> Result<Value, String> {
    let repo = repo;
    match &cli.command {
        Command::Status => value(status(&repo)),
        Command::Describe { message } => value(describe(&repo, message)),
        Command::New => value(new(&repo)),
        Command::Branch { name } => value(branch(&repo, name)),
        Command::Edit { change } => value(edit(&repo, change)),
        Command::Heads => value(heads(&repo)),
        Command::Log => value(log(&repo, None)),
        Command::Evolog { change } => { let id = repo.resolve_change(change).map_err(|e| e.to_string())?; value(evolog(&repo, id)) }
        Command::Blame(arg) => value(blame(&repo, resolve_entity(&repo, &arg.entity).map_err(|e| e.to_string())?)),
        Command::Undo => value(undo(&repo)),
        Command::Merge { change } => value(merge_repo(&repo, change)),
        Command::Conflicts => value(list_conflicts(&repo)),
        Command::Resolve { conflict, take } => {
            value(resolve_conflict(&repo, *conflict, parse_take(take)?))
        }
        Command::Op(OpCommand::Log) => value(op_log(&repo)),
        Command::Op(OpCommand::Restore { index }) => value(op_restore(&repo, OpIx(*index))),
        Command::Changeset(ChangeSetCommand::Begin { name, intent, force }) => {
            value(changeset_begin(&repo, name, parse_intent(intent), None, *force))
        }
        Command::Changeset(ChangeSetCommand::End) => value(changeset_end(&repo)),
        Command::Changeset(ChangeSetCommand::Reopen { changeset }) => {
            let id = resolve_changeset(&repo, changeset).map_err(|e| e.to_string())?.id;
            value(changeset_reopen(&repo, id))
        }
        Command::Push { changeset, dir } => {
            let id = resolve_changeset(&repo, changeset).map_err(|e| e.to_string())?.id;
            let other = svc_repo::sync::open_checkout(dir).map_err(|e| e.to_string())?;
            value(svc_repo::sync::transfer(&repo, &other, id, &svc_repo::checkout_name(&repo)))
        }
        Command::Pull { changeset, dir } => {
            let other = svc_repo::sync::open_checkout(dir).map_err(|e| e.to_string())?;
            let id = resolve_changeset(&other, changeset).map_err(|e| e.to_string())?.id;
            value(svc_repo::sync::transfer(&other, &repo, id, &svc_repo::sync::remote_name(&other)))
        }
        Command::Forge(ForgeCommand::Export { out }) => svc_repo::forge::export(&repo, out.as_deref()).map(|p| json!({"path": p})).map_err(|e| e.to_string()),
        Command::History(HistoryCommand::Export { since, out }) => {
            let b = svc_repo::bundle::export(repo, OpIx(*since)).map_err(|e| e.to_string())?;
            match out {
                Some(p) => {
                    let text = serde_json::to_string_pretty(&b).map_err(|e| e.to_string())?;
                    std::fs::write(p, &text).map_err(|e| e.to_string())?;
                    Ok(json!({"path": p, "ops": b.entries.len()}))
                }
                None => serde_json::to_value(&b).map_err(|e| e.to_string()),
            }
        }
        Command::History(HistoryCommand::Import { file }) => {
            let text = std::fs::read_to_string(file).map_err(|e| e.to_string())?;
            let b: svc_repo::bundle::Bundle = serde_json::from_str(&text).map_err(|e| e.to_string())?;
            let r = svc_repo::bundle::import(repo, &b).map_err(|e| e.to_string())?;
            serde_json::to_value(&r).map_err(|e| e.to_string())
        }
        Command::Changeset(ChangeSetCommand::Status) => value(changeset_status(&repo)),
        Command::Changeset(ChangeSetCommand::List) => value(changesets(&repo)),
        Command::Changeset(ChangeSetCommand::Show { changeset }) => {
            value(changeset_show(&repo, changeset))
        }
        Command::Review(args) => {
            let (kind, text) = review_kind(args)?;
            value(review(&repo, &args.changeset, kind, &text))
        }
        Command::Mail(args) => {
            if let Some(ix) = args.read {
                value(mail_read(&repo, ix))
            } else {
                let to = args.to.as_deref().ok_or("mail: pass a checkout name or @all")?;
                let message = args.message.as_deref().ok_or("mail: pass a message")?;
                value(mail(&repo, to, message, args.about.as_deref()))
            }
        }
        Command::Inbox => value(inbox(&repo)),
        Command::Claim { targets } => value(claim(&repo, targets)),
        Command::Release { targets } => value(release(&repo, targets)),
        Command::Workspace(WorkspaceCommand::Add { name, path, at }) => {
            let change = at
                .as_deref()
                .map(|value| repo.resolve_change(value).map_err(|e| e.to_string()))
                .transpose()?;
            value(workspace::add(&repo, name, path, change))
        }
        Command::Workspace(WorkspaceCommand::List) => value(workspace::list(&repo)),
        Command::Workspace(WorkspaceCommand::Forget { name }) => {
            value(workspace::forget(&repo, name))
        }
        Command::Workspace(WorkspaceCommand::UpdateStale) => value(workspace::update_stale(&repo)),
        Command::Replay => {
            let report = replay(&repo).map_err(|e| e.to_string())?;
            if !report.ok() {
                return Err(format!("replay diverged at {:?}", report.diverged_at));
            }
            value(Ok(report))
        }
        Command::Checkout { snapshot } => {
            let id = snapshot.parse::<SnapshotId>().map_err(|e| e.to_string())?;
            value(checkout(&repo, id))
        }
        Command::Render => { let snapshot = repo.current().map_err(|e| e.to_string())?; repo.render_to_disk(&snapshot).map_err(|e| e.to_string())?; Ok(json!({"rendered": true})) }
        Command::ListDefs => list_defs(&repo),
        Command::ShowDef(arg) => show_def(&repo, &arg.entity, arg.at.as_deref()),
        Command::Show { entity } => show_canonical(&repo, entity),
        Command::Search { query } => search(&repo, query),
        Command::Diff { a, b } => diff(&repo, a, b),
        Command::Rename(args) => rename_cmd(&repo, args),
        Command::Move(args) => move_cmd(&repo, args),
        Command::Relocate(args) => relocate_cmd(&repo, args),
        Command::Extract(args) => extract_cmd(&repo, args),
        Command::Inline(arg) => inline_cmd(&repo, &arg.entity),
        Command::AddDef(args) => add_def_cmd(&repo, args),
        Command::Delete(args) => delete_cmd(&repo, args),
        Command::EditDef(args) => edit_def_cmd(&repo, args),
        Command::Classify(args) => classify_cmd(&repo, args),
        Command::Tui { .. } => unreachable!("handled before the repository opens"),
        command => Err(format!("{} is not wired to the engine yet", command_name(command))),
    }
}

fn value<T: Serialize>(result: svc_core::Result<T>) -> Result<Value, String> {
    serde_json::to_value(result.map_err(|e| e.to_string())?).map_err(|e| e.to_string())
}

fn parse_intent(value: &str) -> Intent {
    match value {
        "refactor" => Intent::Refactor,
        "fix" => Intent::Fix,
        "feature" => Intent::Feature,
        "docs" => Intent::Docs,
        other => Intent::Other(other.to_owned()),
    }
}

fn parse_take(value: &str) -> Result<Take, String> {
    match value {
        "a" => Ok(Take::A),
        "b" => Ok(Take::B),
        "base" => Ok(Take::Base),
        _ => Err("--take: a = current change, b = merged-in, or base".into()),
    }
}

fn review_kind(args: &ReviewArgs) -> Result<(NoteKind, String), String> {
    match (args.approve, args.request_changes, args.note.as_deref()) {
        (true, false, None) => Ok((NoteKind::Approve, String::new())),
        (false, true, None) => Ok((NoteKind::RequestChanges, String::new())),
        (false, false, Some(text)) => Ok((NoteKind::Note, text.into())),
        (false, false, None) => {
            Err("review: pass --approve, --request-changes, or --note <text>".into())
        }
        _ => Err("review: pass exactly one of --approve, --request-changes, --note".into()),
    }
}

fn inbox_text(v: &Value) -> String {
    let unread = v["unread"].as_array();
    match unread {
        Some(items) if items.is_empty() => "inbox empty".into(),
        Some(items) => format!("{} unread", items.len()),
        None => "inbox empty".into(),
    }
}

fn definition_bytes(definition: &str) -> Vec<u8> {
    let mut bytes = definition.as_bytes().to_vec();
    if !bytes.ends_with(b"\n") {
        bytes.push(b'\n');
    }
    bytes
}

fn init_text() -> Result<String, String> {
    let cwd = env::current_dir().map_err(|e| e.to_string())?;
    let repo = Repo::init(&cwd, Repo::default_langs()).map_err(|e| e.to_string())?;
    let n = repo.current().map(|s| s.entities.len()).map_err(|e| e.to_string())?;
    Ok(format!("initialized {} — {n} entities", repo.root_dir().display()))
}

fn show_def_text(repo: &Repo, query: &str, at: Option<&str>) -> Result<String, String> {
    show_def(repo, query, at).map(|v| {
        v["text"].as_str().map(str::to_string).unwrap_or_else(|| serde_json::to_string_pretty(&v).unwrap_or_default())
    })
}

fn list_defs(repo: &Repo) -> Result<Value, String> {
    let snapshot = repo.current().map_err(|e| e.to_string())?;
    Ok(json!({"definitions": snapshot.entities.into_iter().map(|(id, entity)| json!({
        "id": id, "name": entity.name, "kind": entity.kind, "file": entity.file,
        "parent": entity.parent, "ordinal": entity.ordinal
    })).collect::<Vec<_>>() }))
}

fn show_def(repo: &Repo, query: &str, at: Option<&str>) -> Result<Value, String> {
    let snap = match at {
        Some(spec) => resolve_snapshot(repo, spec)?,
        None => repo.current().map_err(|e| e.to_string())?,
    };
    let id = resolve_entity_in(&snap, query).map_err(|e| e.to_string())?;
    let canonical = show(repo.store(), &snap, id).map_err(|e| e.to_string())?;
    let entity = snap.entities.get(&id).cloned().ok_or_else(|| format!("missing {query}"))?;
    let bytes = repo.store().get_bytes_blob(entity.bytes).map_err(|e| e.to_string())?;
    let content = repo.store().get_content(entity.content).map_err(|e| e.to_string())?;
    let (src, _) = render_entity(&snap, repo.store(), id, false).map_err(|e| e.to_string())?;
    let text = String::from_utf8_lossy(&src);
    let notes = notes_about_entity(repo, id).map_err(|e| e.to_string())?;
    Ok(json!({"id": id, "entity": entity, "canonical": canonical, "bytes": bytes, "content": content, "text": text, "notes": notes}))
}

fn show_canonical(repo: &Repo, query: &str) -> Result<Value, String> {
    let id = resolve_entity(repo, query).map_err(|e| e.to_string())?;
    let snapshot = repo.current().map_err(|e| e.to_string())?;
    let canonical = show(repo.store(), &snapshot, id).map_err(|e| e.to_string())?;
    Ok(json!({"id": id, "short": id.short(), "canonical": canonical}))
}

fn mutation_value(m: svc_repo::Mutation) -> Result<Value, String> {
    Ok(json!({
        "op": m.ix,
        "snapshot": m.snapshot,
        "observed": m.entry.observed,
        "flagged": m.entry.flagged(),
        "closed_stale_changeset": m.closed_stale_changeset,
    }))
}

/// The sentence for *this* verb's op (`m.ix` / MutationOut.ix), not `op_log().first()`
/// (newest in the shared journal — wrong when two checkouts publish at once).
fn text_of_this_op(repo: &Repo, v: &Value) -> Result<String, String> {
    use svc_repo::text;
    let snap = repo.current().map_err(|e| e.to_string())?;
    let entries = op_log(repo).map_err(|e| e.to_string())?;
    let want = v["op"].as_u64().or_else(|| v["ix"].as_u64());
    let entry = want
        .and_then(|n| entries.iter().find(|e| e.ix.0 == n))
        .or_else(|| entries.first());
    Ok(entry.map(|e| text::op(&snap, e)).unwrap_or_default())
}

fn search(repo: &Repo, query: &str) -> Result<Value, String> {
    let needle = query.to_ascii_lowercase();
    let snapshot = repo.current().map_err(|e| e.to_string())?;
    let matches = snapshot
        .entities
        .iter()
        .filter(|(id, entity)| {
            id.to_string().to_ascii_lowercase().contains(&needle)
                || entity.name.to_ascii_lowercase().contains(&needle)
                || entity.file.as_str().to_ascii_lowercase().contains(&needle)
                || format!("{:?}", entity.kind).to_ascii_lowercase().contains(&needle)
                || render_entity(&snapshot, repo.store(), **id, false)
                    .ok()
                    .is_some_and(|(src, _)| {
                        String::from_utf8_lossy(&src).to_ascii_lowercase().contains(&needle)
                    })
        })
        .map(|(id, entity)| json!({
            "id": id, "name": entity.name, "kind": entity.kind, "file": entity.file,
            "parent": entity.parent, "ordinal": entity.ordinal,
        }))
        .collect::<Vec<_>>();
    Ok(json!({"matches": matches}))
}

fn resolve_snapshot(repo: &Repo, spec: &str) -> Result<Snapshot, String> {
    if let Ok(id) = spec.parse::<SnapshotId>() {
        if let Ok(snapshot) = repo.store().get_snapshot(id) {
            return Ok(snapshot);
        }
    }
    let change = repo.resolve_change(spec).map_err(|e| e.to_string())?;
    let id = repo
        .store()
        .head(change)
        .map_err(|e| e.to_string())?;
    repo.store().get_snapshot(id).map_err(|e| e.to_string())
}

fn diff(repo: &Repo, a: &str, b: &str) -> Result<Value, String> {
    let a = resolve_snapshot(repo, a)?;
    let b = resolve_snapshot(repo, b)?;
    Ok(json!({"deltas": diff_snapshots(repo.store(), &a, &b).map_err(|e| e.to_string())?}))
}

fn resolve_parent(repo: &Repo, parent: &str) -> Result<Option<EntityId>, String> {
    match parent {
        "root" | "none" | "-" => Ok(None),
        value => resolve_entity(repo, value).map(Some).map_err(|e| e.to_string()),
    }
}

fn rename_cmd(repo: &Repo, args: &RenameArgs) -> Result<Value, String> {
    let id = resolve_entity(repo, &args.entity).map_err(|e| e.to_string())?;
    let old = repo.current().ok().and_then(|s| s.entities.get(&id).map(|r| r.name.clone()));
    let op = Op::Rename { id, new: args.new_name.clone() };
    let m = repo
        .mutate(op, None, |repo, cur| repo.amend(cur, rename(repo.store(), cur, id, &args.new_name)?))
        .map_err(|e| e.to_string())?;
    // Mentions of the old name svc did not resolve (method calls on typed receivers,
    // strings, comments) are left as they were; say how many rather than hide it.
    let untracked = match &old {
        Some(old) if old != &args.new_name => untracked_mentions(repo, old).unwrap_or_default(),
        _ => Default::default(),
    };
    let mut v = mutation_value(m)?;
    v["renamed"] = json!({ "from": old, "to": args.new_name });
    v["untracked_mentions"] = json!(untracked);
    Ok(v)
}

fn move_cmd(repo: &Repo, args: &MoveArgs) -> Result<Value, String> {
    let id = resolve_entity(repo, &args.entity).map_err(|e| e.to_string())?;
    let parent = resolve_parent(repo, &args.new_parent)?;
    let op = Op::Move { id, parent, ordinal: args.ordinal };
    let m = repo
        .mutate(op, None, |repo, cur| repo.amend(cur, move_def(repo.store(), repo.langs(), cur, id, parent, args.ordinal)?))
        .map_err(|e| e.to_string())?;
    mutation_value(m)
}

fn relocate_cmd(repo: &Repo, args: &RelocateArgs) -> Result<Value, String> {
    let id = resolve_entity(repo, &args.entity).map_err(|e| e.to_string())?;
    let file = RelPath::new(args.file.clone()).map_err(|p| format!("invalid --file {p}"))?;
    let op = Op::Relocate { id, file: file.clone(), ordinal: args.ordinal };
    let m = repo
        .mutate(op, None, |repo, cur| repo.amend(cur, relocate(cur, repo.store(), id, file, args.ordinal)?))
        .map_err(|e| e.to_string())?;
    mutation_value(m)
}

fn extract_cmd(repo: &Repo, args: &ExtractArgs) -> Result<Value, String> {
    let id = resolve_entity(repo, &args.entity).map_err(|e| e.to_string())?;
    let parent = args
        .new_parent
        .as_deref()
        .map(|p| resolve_parent(repo, p))
        .transpose()?
        .flatten();
    let ordinal = repo
        .current()
        .map_err(|e| e.to_string())?
        .entities
        .get(&id)
        .map(|e| e.ordinal)
        .ok_or_else(|| format!("no such entity: {}", args.entity))?;
    let op = Op::Extract { id, new_parent: parent, ordinal };
    let m = repo
        .mutate(op, None, |repo, cur| repo.amend(cur, extract_hoist(repo.store(), repo.langs(), cur, id, parent, ordinal)?))
        .map_err(|e| e.to_string())?;
    mutation_value(m)
}

fn inline_cmd(repo: &Repo, entity: &str) -> Result<Value, String> {
    let id = resolve_entity(repo, entity).map_err(|e| e.to_string())?;
    let m = repo
        .mutate(Op::Inline { id }, None, |repo, cur| {
            repo.amend(cur, inline(repo.store(), repo.langs(), cur, id)?)
        })
        .map_err(|e| e.to_string())?;
    mutation_value(m)
}

fn add_def_cmd(repo: &Repo, args: &AddDefArgs) -> Result<Value, String> {
    let id: EntityId = match &args.id {
        Some(id) => serde_json::from_value(Value::String(id.clone()))
            .map_err(|e| format!("invalid entity id: {e}"))?,
        None => EntityId::new(),
    };
    let parent = args
        .parent
        .as_deref()
        .map(|p| resolve_parent(repo, p))
        .transpose()?
        .flatten();
    let intent = parse_intent(&args.intent);
    let definition = definition_bytes(&args.definition);
    let file = match args.file.as_deref() {
        Some(s) => Some(RelPath::new(s).map_err(|p| format!("invalid --file {p}"))?),
        None => None,
    };
    let current = repo.current().map_err(|e| e.to_string())?;
    let file = resolve_add_def_file(&current, repo.langs(), parent, file)
        .map_err(|e| e.to_string())?;
    let op = Op::AddDef {
        id,
        parent,
        ordinal: args.ordinal,
        definition: args.definition.clone(),
        intent: intent.clone(),
        file: Some(file.clone()),
    };
    let m = repo
        .mutate(op, None, |repo, cur| {
            let next = add_def_at(
                repo.store(), repo.langs(), cur, id, parent, Some(file.clone()),
                args.ordinal, &definition, intent,
            )?;
            repo.amend(cur, next)
        })
        .map_err(|e| e.to_string())?;
    mutation_value(m)
}

fn delete_cmd(repo: &Repo, args: &DeleteArgs) -> Result<Value, String> {
    let id = resolve_entity(repo, &args.entity).map_err(|e| e.to_string())?;
    let intent = parse_intent(&args.intent);
    let op = Op::Delete { id, intent };
    let m = repo
        .mutate(op, None, |repo, cur| repo.amend(cur, delete(cur, repo.store(), id)?))
        .map_err(|e| e.to_string())?;
    mutation_value(m)
}

fn edit_def_cmd(repo: &Repo, args: &EditDefArgs) -> Result<Value, String> {
    repo.absorb().map_err(|e| e.to_string())?;
    let id = resolve_entity(repo, &args.entity).map_err(|e| e.to_string())?;
    let current = repo.current().map_err(|e| e.to_string())?;
    let definition = definition_bytes(&args.definition);
    let observed = classify_def(
        repo.store(), repo.langs(), &current, id, &definition,
    )
    .map_err(|e| e.to_string())?;
    let intent = parse_intent(&args.intent);
    let op = Op::EditDef {
        id,
        definition: args.definition.clone(),
        intent,
    };
    let m = repo
        .mutate(op, Some(observed), |repo, cur| {
            let (next, _) = edit_def(
                repo.store(), repo.langs(), cur, id, &definition,
            )?;
            repo.amend(cur, next)
        })
        .map_err(|e| e.to_string())?;
    mutation_value(m)
}

fn classify_cmd(repo: &Repo, args: &ClassifyArgs) -> Result<Value, String> {
    let id = resolve_entity(repo, &args.entity).map_err(|e| e.to_string())?;
    let current = repo.current().map_err(|e| e.to_string())?;
    let definition = definition_bytes(&args.definition);
    let observed = classify_def(
        repo.store(), repo.langs(), &current, id, &definition,
    )
    .map_err(|e| e.to_string())?;
    Ok(json!({"observed": observed, "committed": false}))
}

fn command_name(command: &Command) -> &'static str {
    match command {
        Command::Search { .. } => "search", Command::Diff { .. } => "diff",
        Command::Rename(_) => "rename", Command::Move(_) => "move", Command::Relocate(_) => "relocate",
        Command::Extract(_) => "extract", Command::Inline(_) => "inline", Command::AddDef(_) => "add-def",
        Command::Delete(_) => "delete", Command::EditDef(_) => "edit-def", Command::Classify(_) => "classify",
        Command::Agent { .. } => "agent", Command::Tui { .. } => "tui", Command::Workspace(_) => "workspace", Command::History(_) => "history", Command::Replay => "replay", _ => unreachable!(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use clap::CommandFactory;
    #[test]
    fn harness_shapes_parse() {
        Cli::try_parse_from(["svc", "rename", "--entity", "parse", "--new-name", "parse_config", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "edit-def", "--entity", "load", "--definition", "fn load() {}", "--intent", "refactor", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "list-defs", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "merge", "feature", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "resolve", "0", "--take", "b", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "edit", "feature", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "op", "restore", "7", "--json"]).unwrap();
        Cli::try_parse_from([
            "svc", "workspace", "add", "agent", "/tmp/agent", "--at", "main", "--json",
        ])
        .unwrap();
        Cli::try_parse_from(["svc", "workspace", "list", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "workspace", "forget", "agent", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "replay", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "workspace", "update-stale", "--json"]).unwrap();
        Cli::try_parse_from(["svc", "move", "--entity", "parse", "--new-parent", "root"])
            .unwrap();
        Cli::try_parse_from([
            "svc", "relocate", "--entity", "parse", "--file", "src/parse.rs", "--ordinal", "0",
        ])
        .unwrap();
        Cli::try_parse_from([
            "svc", "add-def", "--id", "018f0000-0000-7000-8000-000000000001",
            "--ordinal", "9", "--definition", "fn added() {}", "--intent", "feature",
        ])
        .unwrap();
        Cli::try_parse_from([
            "svc", "add-def", "--ordinal", "9", "--definition", "fn added() {}", "--intent",
            "feature", "--file", "src/extra.rs",
        ])
        .unwrap();
        Cli::try_parse_from([
            "svc", "classify", "--entity", "validate", "--definition", "fn validate() {}",
        ])
        .unwrap();
        Cli::try_parse_from(["svc", "search", "parse"]).unwrap();
        Cli::try_parse_from(["svc", "diff", "main", "feature"]).unwrap();
        Cli::try_parse_from(["svc", "show-def", "--entity", "parse", "--at", "deadbeef"]).unwrap();
        Cli::try_parse_from(["svc", "history", "export", "--since", "1", "--out", "/tmp/h.json"]).unwrap();
        Cli::try_parse_from(["svc", "history", "import", "/tmp/h.json"]).unwrap();
        Cli::try_parse_from(["svc", "review", "run", "--approve"]).unwrap();
        Cli::try_parse_from(["svc", "review", "run", "--request-changes"]).unwrap();
        Cli::try_parse_from(["svc", "review", "run", "--note", "split this"]).unwrap();
        Cli::try_parse_from(["svc", "mail", "@all", "pushing main"]).unwrap();
        Cli::try_parse_from(["svc", "mail", "--read", "3"]).unwrap();
        Cli::try_parse_from(["svc", "inbox"]).unwrap();
        Cli::try_parse_from(["svc", "claim", "parse"]).unwrap();
        Cli::try_parse_from(["svc", "release"]).unwrap();
        Cli::try_parse_from(["svc", "changeset", "show", "run"]).unwrap();
    }

    #[test]
    fn resolve_take_help_names_the_sides() {
        let mut cmd = Cli::command();
        let help = cmd
            .find_subcommand_mut("resolve")
            .expect("resolve")
            .render_long_help()
            .to_string();
        assert!(help.contains("current change"), "{help}");
        assert!(help.contains("merged-in"), "{help}");
    }
}
