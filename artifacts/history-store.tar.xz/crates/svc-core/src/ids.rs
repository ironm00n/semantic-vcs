use serde::{Deserialize, Serialize};
use uuid::Uuid;

macro_rules! uuid_id {
    ($name:ident) => {
        #[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
        pub struct $name(pub Uuid);

        /// Compact bytes for postcard (the hashed form); hyphenated text for JSON.
        impl Serialize for $name {
            fn serialize<S: serde::Serializer>(
                &self,
                s: S,
            ) -> std::result::Result<S::Ok, S::Error> {
                if s.is_human_readable() {
                    s.serialize_str(&self.0.hyphenated().to_string())
                } else {
                    uuid::serde::compact::serialize(&self.0, s)
                }
            }
        }

        impl<'de> Deserialize<'de> for $name {
            fn deserialize<D: serde::Deserializer<'de>>(
                d: D,
            ) -> std::result::Result<Self, D::Error> {
                if d.is_human_readable() {
                    let s = String::deserialize(d)?;
                    Uuid::parse_str(&s)
                        .map(Self)
                        .map_err(serde::de::Error::custom)
                } else {
                    uuid::serde::compact::deserialize(d).map(Self)
                }
            }
        }

        impl $name {
            pub fn new() -> Self {
                Self(Uuid::now_v7())
            }

            pub fn as_uuid(self) -> Uuid {
                self.0
            }

            /// Short form from blake3 of the id, never the leading timestamp bits of a v7.
            pub fn short(self) -> String {
                short_hex(&self.0.as_bytes()[..])
            }

            /// `spec` names this id if it is a prefix of the short form or of the
            /// dashless uuid; case and dashes in `spec` are ignored.
            pub fn matches_spec(self, spec: &str) -> bool {
                let hex = spec.to_ascii_lowercase().replace('-', "");
                !hex.is_empty()
                    && (self.short().starts_with(&hex)
                        || self.0.simple().to_string().starts_with(&hex))
            }
        }

        impl Default for $name {
            fn default() -> Self {
                Self::new()
            }
        }

        impl std::fmt::Debug for $name {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(f, "{}({})", stringify!($name), self.0)
            }
        }

        impl std::fmt::Display for $name {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(f, "{}", self.0)
            }
        }
    };
}

macro_rules! hash_id {
    ($name:ident) => {
        #[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
        pub struct $name(pub [u8; 32]);

        /// Raw bytes for postcard (the hashed form); 64 hex chars for JSON.
        impl Serialize for $name {
            fn serialize<S: serde::Serializer>(
                &self,
                s: S,
            ) -> std::result::Result<S::Ok, S::Error> {
                if s.is_human_readable() {
                    s.serialize_str(&hex32(&self.0))
                } else {
                    self.0.serialize(s)
                }
            }
        }

        impl<'de> Deserialize<'de> for $name {
            fn deserialize<D: serde::Deserializer<'de>>(
                d: D,
            ) -> std::result::Result<Self, D::Error> {
                if d.is_human_readable() {
                    let s = String::deserialize(d)?;
                    parse_hex32(&s).map(Self).map_err(serde::de::Error::custom)
                } else {
                    <[u8; 32]>::deserialize(d).map(Self)
                }
            }
        }

        impl std::str::FromStr for $name {
            type Err = String;
            fn from_str(s: &str) -> std::result::Result<Self, String> {
                parse_hex32(s).map(Self)
            }
        }

        impl $name {
            pub fn as_bytes(&self) -> &[u8; 32] {
                &self.0
            }

            pub fn short(self) -> String {
                short_hex(&self.0)
            }
        }

        impl std::fmt::Debug for $name {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(f, "{}({})", stringify!($name), hex32(&self.0))
            }
        }

        impl std::fmt::Display for $name {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                f.write_str(&hex32(&self.0))
            }
        }
    };
}

uuid_id!(EntityId);
uuid_id!(ChangeId);
uuid_id!(ChangeSetId);

/// The one id among `ids` that `matches` names. `Err` carries every candidate: empty
/// means none matched, two or more means the spec is ambiguous.
pub fn resolve_spec<I: Copy + Ord>(
    ids: impl IntoIterator<Item = I>,
    matches: impl Fn(I) -> bool,
) -> std::result::Result<I, Vec<I>> {
    let mut hits: Vec<I> = ids.into_iter().filter(|id| matches(*id)).collect();
    hits.sort();
    hits.dedup();
    match hits.as_slice() {
        [one] => Ok(*one),
        _ => Err(hits),
    }
}

impl EntityId {
    /// Declaration-site sentinel. A real self-id makes rename detection circular.
    pub const SELF: Self = Self(Uuid::nil());
}

hash_id!(SnapshotId);
hash_id!(ContentId);
hash_id!(BytesId);

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Debug)]
pub struct OpIx(pub u64);

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Debug)]
pub struct Slot(pub u32);

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Debug)]
pub struct TokenIx(pub u32);

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Debug)]
pub struct AtomIx(pub u32);

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Debug)]
pub struct ByteRange {
    pub start: u32,
    pub end: u32,
}

impl ByteRange {
    pub fn new(start: u32, end: u32) -> Self {
        Self { start, end }
    }

    pub fn len(self) -> u32 {
        self.end.saturating_sub(self.start)
    }

    pub fn contains(self, off: u32) -> bool {
        off >= self.start && off < self.end
    }
}

pub type Timestamp = u64;

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Debug)]
pub struct LineCol {
    /// 1-based.
    pub line: u32,
    /// 0-based.
    pub col: u32,
}

#[derive(Clone, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[serde(try_from = "String")]
pub struct RelPath(String);

impl RelPath {
    pub fn new(s: impl Into<String>) -> Result<Self, String> {
        let s = s.into();
        if s.is_empty() || s.starts_with('/') || s.contains('\0') || s.contains('\\') {
            return Err(s);
        }
        if s.split('/').any(|p| p.is_empty() || p == "." || p == "..") {
            return Err(s);
        }
        Ok(Self(s))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }

    pub fn extension(&self) -> Option<&str> {
        std::path::Path::new(&self.0)
            .extension()
            .and_then(|e| e.to_str())
    }
}

impl std::fmt::Debug for RelPath {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "RelPath({:?})", self.0)
    }
}

impl TryFrom<String> for RelPath {
    type Error = String;

    fn try_from(value: String) -> Result<Self, Self::Error> {
        Self::new(value).map_err(|path| format!("invalid relative path: {:?}", path))
    }
}

impl std::fmt::Display for RelPath {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.0)
    }
}

#[derive(Clone, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize, Debug)]
pub struct ToolCallId(pub String);

pub fn hash_postcard(value: &impl Serialize) -> [u8; 32] {
    let mut hasher = blake3::Hasher::new();
    postcard::to_io(value, &mut hasher).expect("postcard to hasher");
    *hasher.finalize().as_bytes()
}

fn short_hex(bytes: &[u8]) -> String {
    let h = blake3::hash(bytes);
    hex_n(h.as_bytes(), 4)
}

fn hex32(bytes: &[u8; 32]) -> String {
    hex_n(bytes, 32)
}

fn hex_n(bytes: &[u8], n: usize) -> String {
    let mut s = String::with_capacity(n * 2);
    for b in bytes.iter().take(n) {
        s.push_str(&format!("{b:02x}"));
    }
    s
}

impl SnapshotId {
    pub fn of(snapshot: &impl Serialize) -> Self {
        Self(hash_postcard(snapshot))
    }
}

impl ContentId {
    pub fn of(content: &impl Serialize) -> Self {
        Self(hash_postcard(content))
    }
}

impl BytesId {
    pub fn of(bytes: &impl Serialize) -> Self {
        Self(hash_postcard(bytes))
    }
}

fn parse_hex32(s: &str) -> std::result::Result<[u8; 32], String> {
    if s.len() != 64 {
        return Err(format!("expected 64 hex chars, got {}", s.len()));
    }
    let mut out = [0u8; 32];
    for (i, chunk) in s.as_bytes().chunks(2).enumerate() {
        let pair = std::str::from_utf8(chunk).map_err(|e| e.to_string())?;
        out[i] = u8::from_str_radix(pair, 16).map_err(|e| e.to_string())?;
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;

    const INVALID_REL_PATHS: &[&str] = &[
        "", "/absolute.rs", ".", "..", "../escape.rs", "src/../escape.rs",
        "src/./lib.rs", "src//lib.rs", "src/", "src\\lib.rs", "src/\0lib.rs",
    ];

    #[test]
    fn rel_path_json_rejects_invalid_paths_and_map_keys() {
        for &text in INVALID_REL_PATHS {
            assert!(RelPath::new(text).is_err());
            let json = serde_json::to_string(text).unwrap();
            assert!(serde_json::from_str::<RelPath>(&json).is_err(), "{text:?}");
            let map = serde_json::to_string(&BTreeMap::from([(text, 1u8)])).unwrap();
            assert!(serde_json::from_str::<BTreeMap<RelPath, u8>>(&map).is_err(), "{text:?}");
        }
    }

    #[test]
    fn rel_path_postcard_rejects_invalid_paths() {
        for &text in INVALID_REL_PATHS {
            assert!(RelPath::new(text).is_err());
            let encoded = postcard::to_stdvec(text).unwrap();
            assert!(postcard::from_bytes::<RelPath>(&encoded).is_err(), "{text:?}");
        }
    }

    #[test]
    fn rel_path_preserves_valid_wire_encodings_and_map_keys() {
        for text in ["src/lib.rs", ".svcignore", "folder with spaces/café.rs"] {
            let path = RelPath::new(text).unwrap();
            let json = serde_json::to_string(&path).unwrap();
            assert_eq!(json, serde_json::to_string(text).unwrap());
            assert_eq!(serde_json::from_str::<RelPath>(&json).unwrap(), path);
            let encoded = postcard::to_stdvec(&path).unwrap();
            assert_eq!(encoded, postcard::to_stdvec(text).unwrap());
            assert_eq!(postcard::from_bytes::<RelPath>(&encoded).unwrap(), path);
            let map = BTreeMap::from([(path, 1u8)]);
            let json = serde_json::to_string(&map).unwrap();
            assert_eq!(serde_json::from_str::<BTreeMap<RelPath, u8>>(&json).unwrap(), map);
        }
    }

    #[test]
    fn spec_matches_short_prefix_and_dashless_uuid_case_insensitively() {
        let id = EntityId::new();
        assert_eq!(
            id.short().len(),
            8,
            "short ids keep 32 bits to avoid routine collisions"
        );
        assert!(id.matches_spec(&id.short()));
        assert!(id.matches_spec(&id.short()[..2].to_ascii_uppercase()));
        assert!(id.matches_spec(&id.to_string()));
        assert!(id.matches_spec(&id.to_string().replace('-', "")[..10]));
        assert!(!id.matches_spec(""));
        assert!(
            !id.matches_spec(&id.to_string()[3..9]),
            "a middle fragment is not a prefix"
        );
        let other = EntityId::new();
        assert_eq!(resolve_spec([id, other], |i| i == id), Ok(id));
        assert_eq!(
            resolve_spec([id, other], |_| true),
            Err(vec![id.min(other), id.max(other)])
        );
        assert_eq!(resolve_spec([id, other], |_| false), Err(vec![]));
    }

    #[test]
    fn ids_are_compact_in_postcard_and_text_in_json() {
        let c = ChangeId::new();
        assert_eq!(postcard::to_stdvec(&c).unwrap().len(), 16);
        let json = serde_json::to_string(&c).unwrap();
        assert_eq!(json, format!("\"{}\"", c.0.hyphenated()));
        assert_eq!(serde_json::from_str::<ChangeId>(&json).unwrap(), c);
        assert_eq!(
            postcard::from_bytes::<ChangeId>(&postcard::to_stdvec(&c).unwrap()).unwrap(),
            c
        );

        let h = SnapshotId([7; 32]);
        assert_eq!(postcard::to_stdvec(&h).unwrap().len(), 32);
        let json = serde_json::to_string(&h).unwrap();
        assert_eq!(json.len(), 66);
        assert_eq!(serde_json::from_str::<SnapshotId>(&json).unwrap(), h);
        assert_eq!(json.trim_matches('"').parse::<SnapshotId>().unwrap(), h);
    }
}
